    //    window.onload=function()
    //    {
    //     alert("after document loaded")
    //    }
    console.log(document.readyState);
    // document.onreadystatechange=function()
    // {
    //     if(document.readyState=="complete")
    //     {
    //         //write js code here
    //         alert("now document is ready , you can proceed with code");
    //     }
    // }

    document.addEventListener('readystatechange',function(){
        console.log(document.readyState)
    });
